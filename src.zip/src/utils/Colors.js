const Colors = {
    PrimaryColor: '#D10054',
    PrimaryColorPink: '#D10054',
    PrimaryColorBlue: '#58CCED',
    black:'black',
    White: 'white',
    TextColor:'#868686',
    darkText:'#3C3737',
    seprator:'#DDDDDD',
    LightBlue:'#DBF7FF',
   LightPink:'#FEE9F1',
   LightBackground:'#F5F5F5',
   DarkBlue:'#2BA8CB',

   //

   RED:'#F00000',
   BLUE:'#363A61'


   

//    1 - B74F48

// 2- F00000
    
}
export default Colors;