import myAppointment from './myAppointment.js';
// import { NavigationActions } from 'react-navigation';
// import { connect } from 'react-redux';
// import { bindActionCreators } from 'redux';
// import { loginWithPhone } from './../../modules/LoginPhone';


// const mapStateToProps = state => ({
//  isBusy: state.AuthReducer.isBusy,
//  response: state.AuthReducer
//  });


// export default connect(
//  mapStateToProps,
//  dispatch => {
//    return {
//      loginWithPhone: bindActionCreators(loginWithPhone, dispatch),
//      navigate: bindActionCreators(NavigationActions.navigate, dispatch)
//    };
//  }
// )(Login);
export default myAppointment;
