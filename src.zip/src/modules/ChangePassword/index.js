import {
  changePasswordAPI
} from './actions';
import reducer from './reducer';

export {
  changePasswordAPI
};

export default reducer;
