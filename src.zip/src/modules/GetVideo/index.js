import {
  getVideoAPI
} from './actions';
import reducer from './reducer';

export {
  getVideoAPI
};

export default reducer;
