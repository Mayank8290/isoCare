export const GETVIDEO_REQUEST = 'GetVideo/GETVIDEO_REQUEST';
export const GETVIDEO_SUCCESS = 'GetVideo/GETVIDEO_SUCCESS';
export const GETVIDEOG_FAILURE = 'GetVideo/GETVIDEO_FAILURE';

export type State = {
  error: string | null
};
