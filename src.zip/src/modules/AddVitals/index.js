import {
  AddVitals
} from './actions';
import reducer from './reducer';

export {
  AddVitals
};

export default reducer;
