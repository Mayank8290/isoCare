export const AddVitals_REQUEST = 'AddVitals/AddVitals_REQUEST';
export const AddVitals_SUCCESS = 'AddVitals/AddVitals_SUCCESS';
export const AddVitals_FAILURE = 'AddVitals/AddVitals_FAILURE';

export type State = {
  error: string | null
};
