import {
  getProfileAPI
} from './actions';
import reducer from './reducer';

export {
  getProfileAPI
};

export default reducer;
