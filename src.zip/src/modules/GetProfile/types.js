export const GETPROFILE_REQUEST = 'GetProfile/GETPROFILE_REQUEST';
export const GETPROFILE_SUCCESS = 'GetProfile/GETPROFILE_SUCCESS';
export const GETPROFILE_FAILURE = 'GetProfile/GETPROFILE_FAILURE';

export type State = {
  error: string | null
};
