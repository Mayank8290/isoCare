import {
  GetMessages
} from './actions';
import reducer from './reducer';

export {
  GetMessages
};

export default reducer;
