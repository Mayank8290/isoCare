import {
  resendAPI
} from './actions';
import reducer from './reducer';

export {
  resendAPI
};

export default reducer;
