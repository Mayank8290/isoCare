import {
  submitAnswerAPI
} from './actions';
import reducer from './reducer';

export {
  submitAnswerAPI
};

export default reducer;
