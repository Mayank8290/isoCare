export const SUBMITANSWER_REQUEST = 'SubmitAnswer/SUBMITANSWER_REQUEST';
export const SUBMITANSWER_SUCCESS = 'SubmitAnswer/SUBMITANSWER_SUCCESS';
export const SUBMITANSWER_FAILURE = 'SubmitAnswer/SUBMITANSWER_FAILURE';


export type State = {
  error: string | null
};
