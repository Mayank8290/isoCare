export const EDITPROFILE_REQUEST = 'EditProfile/EDITPROFILE_REQUEST';
export const EDITPROFILE_SUCCESS = 'EditProfile/EDITPROFILE_SUCCESS';
export const EDITPROFILE_FAILURE = 'EditProfile/EDITPROFILE_FAILURE';

export type State = {
  error: string | null
};
