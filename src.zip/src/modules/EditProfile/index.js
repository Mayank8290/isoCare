import {
  EditProfileAPI
} from './actions';
import reducer from './reducer';

export {
  EditProfileAPI
};

export default reducer;
