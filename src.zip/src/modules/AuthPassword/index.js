import {
  checkPasswordAPI
} from './actions';
import reducer from './reducer';

export {
  checkPasswordAPI
};

export default reducer;
