import {
  registerAPI
} from './actions';
import reducer from './reducer';

export {
  registerAPI
};

export default reducer;
