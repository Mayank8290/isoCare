import {
  supportAPI
} from './actions';
import reducer from './reducer';

export {
  supportAPI
};

export default reducer;
