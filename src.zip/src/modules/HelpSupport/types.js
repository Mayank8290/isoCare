export const SUPPORT_REQUEST = 'HelpSupport/SUPPORT_REQUEST';
export const SUPPORT_SUCCESS = 'HelpSupport/SUPPORT_SUCCESS';
export const SUPPORT_FAILURE = 'HelpSupport/SUPPORT_FAILURE';
