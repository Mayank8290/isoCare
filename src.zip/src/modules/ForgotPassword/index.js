import {
  forgotPasswordAPI
} from './actions';
import reducer from './reducer';

export {
  forgotPasswordAPI
};

export default reducer;
