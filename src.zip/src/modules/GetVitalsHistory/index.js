import {
  GetVitalsHistory
} from './actions';
import reducer from './reducer';

export {
  GetVitalsHistory
};

export default reducer;
