export const GetVitalsHistory_REQUEST = 'GetVitalsHistory/GetVitalsHistory_REQUEST';
export const GetVitalsHistory_SUCCESS = 'GetVitalsHistory/GetVitalsHistory_SUCCESS';
export const GetVitalsHistory_FAILURE = 'GetVitalsHistory/GetVitalsHistory_FAILURE';

export type State = {
  error: string | null
};
