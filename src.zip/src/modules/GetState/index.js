import {
  getStateAPI
} from './actions';
import reducer from './reducer';

export {
  getStateAPI
};

export default reducer;
