import {
  GetInformation
} from './actions';
import reducer from './reducer';

export {
  GetInformation
};

export default reducer;
