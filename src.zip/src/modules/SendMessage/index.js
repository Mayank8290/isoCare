import {
  SendMessage
} from './actions';
import reducer from './reducer';

export {
  SendMessage
};

export default reducer;
