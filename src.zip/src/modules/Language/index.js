import {
  getSelectedLanguage
} from './actions';
import reducer from './reducer';

export {
  getSelectedLanguage
};

export default reducer;
