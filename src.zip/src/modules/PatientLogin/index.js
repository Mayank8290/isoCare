import {
  PatientLogin
} from './actions';
import reducer from './reducer';

export {
  PatientLogin
};

export default reducer;
