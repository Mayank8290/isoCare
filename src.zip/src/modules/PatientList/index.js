import {
  PatientList
} from './actions';
import reducer from './reducer';

export {
  PatientList
};

export default reducer;
