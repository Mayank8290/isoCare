export const GETQUESTION_REQUEST = 'GetQuestion/GETQUESTION_REQUEST';
export const GETQUESTION_SUCCESS = 'GetQuestion/GETQUESTION_SUCCESS';
export const GETQUESTION_FAILURE = 'GetQuestion/GETQUESTION_FAILURE';

export type State = {
  error: string | null
};
