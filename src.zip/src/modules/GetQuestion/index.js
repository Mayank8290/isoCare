import {
  getQusetionAPI
} from './actions';
import reducer from './reducer';

export {
  getQusetionAPI
};

export default reducer;
