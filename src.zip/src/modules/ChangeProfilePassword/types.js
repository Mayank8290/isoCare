export const CHANGE_PROFILE_PASSWORD_REQUEST = 'ChangeProfilePassword/CHANGE_PROFILE_PASSWORD_REQUEST';
export const CHANGE_PROFILE_PASSWORD_SUCCESS = 'ChangeProfilePassword/CHANGE_PROFILE_PASSWORD_SUCCESS';
export const CHANGE_PROFILE_PASSWORD_FAILURE = 'ChangeProfilePassword/CHANGE_PROFILE_PASSWORD_FAILURE';


export type State = {
  error: string | null
};
