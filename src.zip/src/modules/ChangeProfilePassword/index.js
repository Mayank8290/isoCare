import {
  changeProfilePasswordAPI
} from './actions';
import reducer from './reducer';

export {
  changeProfilePasswordAPI
};

export default reducer;
