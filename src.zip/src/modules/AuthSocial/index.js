import {
  loginWithSocial
} from './actions';
import reducer from './reducer';

export {
  loginWithSocial
};

export default reducer;
