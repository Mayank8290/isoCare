export const LOGIN_WITH_SOCIAL_REQUEST = 'AuthSocial/LOGIN_WITH_SOCIAL_REQUEST';
export const LOGIN_WITH_SOCIAL_SUCCESS = 'AuthSocial/LOGIN_WITH_SOCIAL_SUCCESS';
export const LOGIN_WITH_SOCIAL_FAILURE = 'AuthSocial/LOGIN_WITH_SOCIAL_FAILURE';


export type State = {
  error: string | null
};
